<?php

// import data/person.php
require_once "data/Person.php";

// buat object new person dengan 2 parameter
$rafsha = new Person("rafsha", "linggau");

// vardump object
var_dump($rafsha);
