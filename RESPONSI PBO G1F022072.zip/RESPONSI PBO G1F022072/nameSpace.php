<?php

require_once "data/Conflict.php";

$conflict1 = new Data\One\Conflict();
$conflict2 = new Data\Two\Conflict();