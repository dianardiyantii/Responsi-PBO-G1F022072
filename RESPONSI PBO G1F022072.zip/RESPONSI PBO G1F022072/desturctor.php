<?php

// import data/person.php
require_once "data/Person.php";

// buat 2 object new peson dengan parameter yang berbeda
$rafsha = new Person("rafsha", "linggau");
$syauqi = new Person("syauqi", "bengkulu");

// tambahkan echo "Program Selesai" . PHP_EOL;
echo "Program Selesai" . PHP_EOL;
