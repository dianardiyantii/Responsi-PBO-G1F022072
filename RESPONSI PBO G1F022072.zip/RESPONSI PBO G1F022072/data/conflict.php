<?php

namespace Data\One{
    class Conflict
    {

    }
}

namespace Data\Two{
    class Conflict
    {

    }
}
